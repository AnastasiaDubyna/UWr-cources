let example = "some string";

console.log(example);