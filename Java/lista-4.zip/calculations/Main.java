package calculations;

public class Main {

    public static void main(String[] args) {
        Multiplication mult = new Multiplication(new Number(2), new Number(8));
        System.out.println(mult.calculate());

    }

}

