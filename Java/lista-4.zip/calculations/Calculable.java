package calculations;

public interface Calculable {
    int calculate();
}
